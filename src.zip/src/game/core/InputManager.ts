export class InputManager {
  private keys: Set<string> = new Set();
  private canvas: HTMLCanvasElement;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.setupEventListeners();

    // S'assurer que le canvas peut recevoir le focus
    this.canvas.tabIndex = 0;
    this.canvas.focus();
  }

  private setupEventListeners(): void {
    // Écouter les événements sur le document pour capturer toutes les touches
    document.addEventListener("keydown", this.handleKeyDown.bind(this));
    document.addEventListener("keyup", this.handleKeyUp.bind(this));

    // Écouter le clic sur le canvas pour lui donner le focus
    this.canvas.addEventListener("click", () => {
      this.canvas.focus();
    });

    // Prévenir le comportement par défaut pour certaines touches
    document.addEventListener("keydown", (event) => {
      // Empêcher le scroll avec les flèches et la barre d'espace
      if (
        ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(
          event.key
        )
      ) {
        event.preventDefault();
      }
    });
  }

  private handleKeyDown(event: KeyboardEvent): void {
    this.keys.add(event.key);
  }

  private handleKeyUp(event: KeyboardEvent): void {
    this.keys.delete(event.key);
  }

  public isKeyPressed(key: string): boolean {
    return this.keys.has(key);
  }

  // Méthodes de commodité pour les contrôles du joueur
  public isLeftPressed(): boolean {
    return (
      this.isKeyPressed("ArrowLeft") ||
      this.isKeyPressed("a") ||
      this.isKeyPressed("A")
    );
  }

  public isRightPressed(): boolean {
    return (
      this.isKeyPressed("ArrowRight") ||
      this.isKeyPressed("d") ||
      this.isKeyPressed("D")
    );
  }

  public isJumpPressed(): boolean {
    return (
      this.isKeyPressed(" ") ||
      this.isKeyPressed("ArrowUp") ||
      this.isKeyPressed("w") ||
      this.isKeyPressed("W")
    );
  }

  public isPausePressed(): boolean {
    return (
      this.isKeyPressed("Escape") ||
      this.isKeyPressed("p") ||
      this.isKeyPressed("P")
    );
  }

  // Nettoyer les event listeners
  public destroy(): void {
    document.removeEventListener("keydown", this.handleKeyDown.bind(this));
    document.removeEventListener("keyup", this.handleKeyUp.bind(this));
  }

  // Debug : obtenir toutes les touches pressées
  public getPressedKeys(): string[] {
    return Array.from(this.keys);
  }
}
