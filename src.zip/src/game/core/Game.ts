import { GameLoop } from "./GameLoop";
import { InputManager } from "./InputManager";
import { Renderer } from "../renderer/Renderer";
import { Player } from "../entities/Player";
import { GAME_CONFIG } from "../utils/Constants";

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private gameLoop!: GameLoop;
  private inputManager!: InputManager;
  private renderer!: Renderer;
  private player!: Player;
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private lastTime: number = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext("2d");

    if (!context) {
      throw new Error("Impossible d'obtenir le contexte 2D du canvas");
    }

    this.ctx = context;
    this.setupCanvas();
    this.initializeGame();
  }

  private setupCanvas(): void {
    this.canvas.width = GAME_CONFIG.CANVAS.WIDTH;
    this.canvas.height = GAME_CONFIG.CANVAS.HEIGHT;

    // Améliorer le rendu
    this.ctx.imageSmoothingEnabled = false;

    // Style du canvas
    this.canvas.style.border = "2px solid #333";
    this.canvas.style.backgroundColor = GAME_CONFIG.CANVAS.BACKGROUND_COLOR;
  }

  private initializeGame(): void {
    // Initialiser les systèmes de base
    this.inputManager = new InputManager(this.canvas);
    this.renderer = new Renderer(this.canvas); // Passer le canvas au lieu du contexte

    // Créer le joueur
    this.player = new Player(
      GAME_CONFIG.PLAYER.STARTING_X,
      GAME_CONFIG.PLAYER.STARTING_Y
    );

    // Initialiser la boucle de jeu (sans paramètres selon votre structure)
    this.gameLoop = new GameLoop();

    // Configurer les callbacks de la boucle de jeu
    this.setupGameLoop();
  }

  private setupGameLoop(): void {
    // Si votre GameLoop a des méthodes pour définir les callbacks
    // Adaptez selon votre implémentation existante
    // Par exemple :
    // this.gameLoop.setUpdateCallback(this.update.bind(this));
    // this.gameLoop.setRenderCallback(this.render.bind(this));
  }

  private update(deltaTime: number): void {
    if (this.isPaused) return;

    // Gestion des inputs
    this.handleInput();

    // Mise à jour du joueur
    this.player.update(deltaTime);
  }

  private handleInput(): void {
    // Vérifier la pause
    if (this.inputManager.isPausePressed()) {
      this.togglePause();
    }

    // Contrôles du joueur
    let isMoving = false;

    if (this.inputManager.isLeftPressed()) {
      this.player.moveLeft();
      isMoving = true;
    }

    if (this.inputManager.isRightPressed()) {
      this.player.moveRight();
      isMoving = true;
    }

    if (this.inputManager.isJumpPressed()) {
      this.player.jump();
    }

    // Si aucun mouvement horizontal, laisser la friction agir
    if (!isMoving) {
      this.player.stopHorizontalMovement();
    }
  }

  private render(): void {
    // Nettoyer le canvas
    this.renderer.clear();

    // Dessiner le sol temporaire
    this.renderTemporaryGround();

    // Dessiner le joueur
    this.player.render(this.ctx);

    // Afficher les informations de debug
    if (GAME_CONFIG.DEBUG.SHOW_FPS) {
      this.renderDebugInfo();
    }
  }

  private renderTemporaryGround(): void {
    const groundHeight = 50;
    this.ctx.fillStyle = "#8B4513"; // Marron
    this.ctx.fillRect(
      0,
      GAME_CONFIG.CANVAS.HEIGHT - groundHeight,
      GAME_CONFIG.CANVAS.WIDTH,
      groundHeight
    );
  }

  private renderDebugInfo(): void {
    // Calculer les FPS à partir du deltaTime
    const fps =
      this.lastTime > 0
        ? Math.round(1 / (performance.now() / 1000 - this.lastTime))
        : 60;
    const playerVel = this.player.velocity;
    const playerPos = this.player.position;

    this.ctx.fillStyle = "white";
    this.ctx.font = "16px Arial";
    this.ctx.fillText(`FPS: ${fps}`, 10, 30);
    this.ctx.fillText(
      `Pos: (${playerPos.x.toFixed(0)}, ${playerPos.y.toFixed(0)})`,
      10,
      50
    );
    this.ctx.fillText(
      `Vel: (${playerVel.x.toFixed(1)}, ${playerVel.y.toFixed(1)})`,
      10,
      70
    );
    this.ctx.fillText(
      `Au sol: ${this.player.isOnGround ? "Oui" : "Non"}`,
      10,
      90
    );

    if (this.isPaused) {
      this.ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
      this.ctx.fillRect(
        0,
        0,
        GAME_CONFIG.CANVAS.WIDTH,
        GAME_CONFIG.CANVAS.HEIGHT
      );
      this.ctx.fillStyle = "white";
      this.ctx.font = "48px Arial";
      this.ctx.textAlign = "center";
      this.ctx.fillText(
        "PAUSE",
        GAME_CONFIG.CANVAS.WIDTH / 2,
        GAME_CONFIG.CANVAS.HEIGHT / 2
      );
      this.ctx.textAlign = "left";
    }
  }

  public start(): void {
    if (!this.isRunning) {
      this.isRunning = true;
      // Démarrer manuellement la boucle de jeu
      this.startGameLoop();
      console.log("Jeu démarré");
    }
  }

  private startGameLoop(): void {
    const gameLoop = (timestamp: number) => {
      if (!this.isRunning) return;

      // Calculer deltaTime
      const currentTime = timestamp / 1000; // Convertir en secondes
      const deltaTime = Math.min(
        currentTime - this.lastTime,
        GAME_CONFIG.PHYSICS.DELTA_TIME_MAX
      );
      this.lastTime = currentTime;

      // Mettre à jour et rendre
      this.update(deltaTime);
      this.render();

      // Continuer la boucle
      requestAnimationFrame(gameLoop);
    };

    this.lastTime = performance.now() / 1000;
    requestAnimationFrame(gameLoop);
  }

  public stop(): void {
    if (this.isRunning) {
      this.isRunning = false;
      console.log("Jeu arrêté");
    }
  }

  public togglePause(): void {
    this.isPaused = !this.isPaused;
    console.log(this.isPaused ? "Jeu en pause" : "Jeu repris");
  }

  public destroy(): void {
    this.stop();
    this.inputManager.destroy();
  }

  // Getters pour les tests
  public getPlayer(): Player {
    return this.player;
  }

  public getIsRunning(): boolean {
    return this.isRunning;
  }

  public getIsPaused(): boolean {
    return this.isPaused;
  }
}
