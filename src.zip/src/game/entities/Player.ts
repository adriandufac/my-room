import { Vector2D } from "../physics/Vector2D";
import { GAME_CONFIG } from "../utils/Constants";

export class Player {
  public position: Vector2D;
  public velocity: Vector2D;
  public size: Vector2D;
  public color: string;
  public isOnGround: boolean;
  public isJumping: boolean;

  constructor(x: number, y: number) {
    this.position = new Vector2D(x, y);
    this.velocity = new Vector2D(0, 0);
    this.size = new Vector2D(
      GAME_CONFIG.PLAYER.WIDTH,
      GAME_CONFIG.PLAYER.HEIGHT
    );
    this.color = GAME_CONFIG.PLAYER.COLOR;
    this.isOnGround = false;
    this.isJumping = false;
  }

  public update(deltaTime: number): void {
    // Appliquer la gravité
    if (!this.isOnGround) {
      this.velocity.y += GAME_CONFIG.PHYSICS.GRAVITY * deltaTime;
    }

    // Limiter la vitesse de chute
    if (this.velocity.y > GAME_CONFIG.PHYSICS.MAX_FALL_SPEED) {
      this.velocity.y = GAME_CONFIG.PHYSICS.MAX_FALL_SPEED;
    }

    // Mettre à jour la position
    this.position.x += this.velocity.x * deltaTime;
    this.position.y += this.velocity.y * deltaTime;

    // Collision avec le sol (temporaire - sera remplacé par les plateformes)
    if (this.position.y + this.size.y > GAME_CONFIG.CANVAS.HEIGHT - 50) {
      this.position.y = GAME_CONFIG.CANVAS.HEIGHT - 50 - this.size.y;
      this.velocity.y = 0;
      this.isOnGround = true;
      this.isJumping = false;
    } else {
      this.isOnGround = false;
    }

    // Limites horizontales du canvas
    if (this.position.x < 0) {
      this.position.x = 0;
      this.velocity.x = 0;
    } else if (this.position.x + this.size.x > GAME_CONFIG.CANVAS.WIDTH) {
      this.position.x = GAME_CONFIG.CANVAS.WIDTH - this.size.x;
      this.velocity.x = 0;
    }

    // Friction horizontale
    this.velocity.x *= GAME_CONFIG.PHYSICS.FRICTION;
  }

  public moveLeft(): void {
    this.velocity.x = -GAME_CONFIG.PLAYER.SPEED;
  }

  public moveRight(): void {
    this.velocity.x = GAME_CONFIG.PLAYER.SPEED;
  }

  public jump(): void {
    if (this.isOnGround && !this.isJumping) {
      this.velocity.y = -GAME_CONFIG.PLAYER.JUMP_POWER;
      this.isOnGround = false;
      this.isJumping = true;
    }
  }

  public stopHorizontalMovement(): void {
    // Arrêt progressif grâce à la friction
    // La friction est appliquée dans update()
  }

  public render(ctx: CanvasRenderingContext2D): void {
    ctx.fillStyle = this.color;
    ctx.fillRect(
      Math.round(this.position.x),
      Math.round(this.position.y),
      this.size.x,
      this.size.y
    );

    // Debug : afficher un point au centre pour le debug
    if (GAME_CONFIG.DEBUG.SHOW_PLAYER_CENTER) {
      ctx.fillStyle = "white";
      ctx.fillRect(
        Math.round(this.position.x + this.size.x / 2 - 2),
        Math.round(this.position.y + this.size.y / 2 - 2),
        4,
        4
      );
    }
  }

  public getBounds(): { x: number; y: number; width: number; height: number } {
    return {
      x: this.position.x,
      y: this.position.y,
      width: this.size.x,
      height: this.size.y,
    };
  }
}
