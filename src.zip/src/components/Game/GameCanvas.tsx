import React, { useEffect, useRef } from "react";

interface GameCanvasProps {
  onGameReady?: (game: any) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({ onGameReady }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<any>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Note: Ce composant est un exemple d'interface
    // Dans votre projet, vous devrez importer et utiliser votre classe Game

    console.log("Canvas prêt pour l'initialisation du jeu");
    console.log("Contrôles prévus:");
    console.log("- Flèches gauche/droite ou A/D : Déplacement");
    console.log("- Barre d'espace ou flèche haut ou W : Saut");
    console.log("- Échap ou P : Pause");

    // Simuler l'initialisation du jeu pour la démo
    const mockGame = {
      start: () => console.log("Jeu démarré"),
      stop: () => console.log("Jeu arrêté"),
      destroy: () => console.log("Jeu détruit"),
      getIsRunning: () => true,
      getIsPaused: () => false,
    };

    gameRef.current = mockGame;

    if (onGameReady) {
      onGameReady(mockGame);
    }

    // Dans votre projet, utilisez ceci à la place :
    /*
    try {
      const game = new Game(canvasRef.current);
      gameRef.current = game;
      game.start();
      
      if (onGameReady) {
        onGameReady(game);
      }
    } catch (error) {
      console.error('Erreur lors de l\'initialisation du jeu:', error);
    }
    */

    // Nettoyage lors du démontage du composant
    return () => {
      if (gameRef.current && gameRef.current.destroy) {
        gameRef.current.destroy();
        gameRef.current = null;
      }
    };
  }, [onGameReady]);

  // Gérer la perte de focus
  const handleCanvasBlur = () => {
    // Optionnel : mettre le jeu en pause quand il perd le focus
    // if (gameRef.current && !gameRef.current.getIsPaused()) {
    //   gameRef.current.togglePause();
    // }
  };

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: "20px",
        backgroundColor: "#f0f0f0",
      }}
    >
      <div style={{ position: "relative" }}>
        <canvas
          ref={canvasRef}
          onBlur={handleCanvasBlur}
          style={{
            display: "block",
            boxShadow: "0 4px 8px rgba(0,0,0,0.3)",
            borderRadius: "4px",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: "-40px",
            left: "0",
            right: "0",
            textAlign: "center",
            fontSize: "14px",
            color: "#666",
            fontFamily: "Arial, sans-serif",
          }}
        >
          Utilisez les flèches ou WASD pour bouger, Espace pour sauter, Échap
          pour pause
        </div>
      </div>
    </div>
  );
};
